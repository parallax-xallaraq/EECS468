/*
Author: Thresa Kelly.
Date: 10/30/23.
File: EECS 468 Assignment 6.
Description: Contains functions to start a server with PUT, GET, DELETE, MKCOL to read, write, and 
  delete files and create a directory on the server, respectively.
Inputs: files.
Outputs: files. 
Sources: Referenced the lecture slides 20-23 and https://www.geeksforgeeks.org/how-to-create-a-directory-using-node-js/.
Replit link: https://replit.com/join/qnmdgbjncc-polaris133pc
*/


// === CREATING A SERVER === 
// --- Referenced the lecture slides 20-23 ---

// get createServer from http module 
const {createServer} = require("http");
const methods = Object.create(null);

// create the file server 
let server = createServer((request, response) => {
  // request -- incoming from client to server
  // response -- outgoing from server to client
  let handler = methods[request.method] || notAllowed;
  // the methods[request.method] array will reject (catch) or resolve (then) 
  // this promise to handle the request
  handler(request)
    // When a request handler’s promise is rejected, the catch call translates the errorinto a 
    // response object to inform the client that it failed to handle the request.
    .catch(error => {
      if (error.status!= null) return error;
      // If the thrown error does not have a status code, the handler adds one (500).
      // The HTTP 500 Internal Server Error server error response code indicates that the server
      // encountered an unexpected condition that prevented it from fulfilling the request.
      return {body: String(error), status: 500};
    })
    // When the request handler’s promise is resolved, then...
    // // The status field of the response defaults to 200 (OK).
    // // The content type, in the type property, defaults to plain text.
    .then(({body, status = 200, type = "text/plain"}) => { //
      response.writeHead(status, {"Content-Type": type});
      // When the value of body is a readable stream, it will have a pipe method that is used 
      // to forward all content from a readable stream to a writable stream.
      if (body && body.pipe) body.pipe(response);
      // If value of body is NOT a readable stream, it is assumed to be either null (no body), 
      // a string, or a buffer, and it is passed directly to the response’s end method.
      else response.end(body);
    });
}).listen(8000);

// returns the 405, “Method not allowed” message.
async function notAllowed(request) {
  console.log(`405 Method ${request.method} is not supported.`)
  return {
    status: 405, // status code
    body: `Method ${request.method} is not supported.` // message 
  };
}

// === READING A FILE (GET) ===
// --- Referenced the lecture slides 20-23 ---

// get createReadStream, stat, readdir from fs module
const {createReadStream} = require("fs");
const {stat, readdir} = require("fs").promises;
// get mine from mime module 
const mime = require("mime");

// GET method to return a list of files when reading a directory and to return the file's 
// content when reading a regular file  
methods.GET= async function(request) {
  // parse the URL
  let path = urlPath(request.url);
  // invoke stat object called stats
  let stats;
  try {
    // The stats object returned by stat tells us a number of things about a file, such as its size 
    // (sizeproperty) and its modification date (mtime property). Here we are interested in the 
    // question of whether it is a directory or a regular file, which the isDirectorymethod tells us.
    stats= await stat(path);
  } catch (error) {
    // When the file does not exist, statwill throw an error object with a code property of "ENOENT"
    if (error.code!= "ENOENT") throw error;
    else return {status: 404, body: "File not found"};
  }
  // If it is a directory, we use readdir to read the array of files in a directory and return it to 
  // the client. For normal files, we create a readable stream with createReadStreamand return that 
  // as the body.
  if (stats.isDirectory()) {
    return {body: (await readdir(path)).join("\n")};
  } else {
    return {body: createReadStream(path),
            type: mime.getType(path)};  // The mimepackage knows the correct type for a large number 
                                        // of file extensions.
  }
};

// get parse from url module 
const {parse} = require("url");
// get resolve, sep from path module 
const {resolve, sep} = require("path");
// set baseDirectory to current working directory (cwd)
const baseDirectory= process.cwd();

// To figure out which file path corresponds to a request URL, the urlPathfunction uses Node’s 
// built-in urlmodule to parse the URL. It takes its path-name, decodes that to get rid of the 
// %20-style escape codes, and resolves it relative to the program’s current working directory (cwd).
function urlPath(url){
  let {pathname} = parse(url);
  // resolves relative paths
  let path = resolve(decodeURIComponent(pathname).slice(1));
  // The sep binding from the path package is the system’s path separator
  if (path != baseDirectory && !path.startsWith(baseDirectory+ sep)) {
    // When the path doesn’t start with the base directory, the function throws an error response 
    // object, using the HTTP status code indicating that access to the resource is forbidden.
    throw {status: 403, body: "Forbidden"};
  }
  return path;
}

// === WRITING A FILE (PUT) ===
// --- Referenced the lecture slides 20-23 ---

// get createWriteStream from fs
const {createWriteStream} = require("fs");

// creates a promise around the outcome of calling pipe.
function pipeStream(from, to) {
  return new Promise((resolve, reject) => {
    // When something goes wrong when opening the file, createWriteStreamwill still return a stream, 
    // but that stream will fire an "error" event.
    from.on("error", reject);
    // The stream from the request may also fail, for example if the network goes down. So we make 
    // both streams’ "error" events to reject the promise.
    to.on("error", reject);
    // When pipe is done, it will close the output stream, which causes it to fire a "finish" event.
    // That’s the point where we can successfully resolve the promise (returning nothing).
    to.on("finish", resolve);
    from.pipe(to);  
  });
}
// PUT method to create a file when writing a file to a directory
methods.PUT= async function(request) {
  let path = urlPath(request.url);
  // use pipe to move data from a readable stream to a writable one
  await pipeStream(request, createWriteStream(path));
  return {status: 204};
};

// === DELETING A FILE (DELETE) ===
// --- Referenced the lecture slides 20-23 ---

//get rmdir (removes a directory), unlink (removes a file) from fs module
const {rmdir, unlink} = require("fs").promises;

methods.DELETE= async function(request) {
  // translate the urlinto a file name
  let path = urlPath(request.url);
  // invoke stat object called stats
  let stats;
  // wait for stat to find the file
  try {
    stats = await stat(path);
  // handle a non-existent file name
  } catch (error) {
    if (error.code!= "ENOENT") throw error;
    // When an HTTP response does not contain any data, the status code is 204 (“no content”)
    else return {status: 204};
  }
  // if the file name is a directory, remove it
  if (stats.isDirectory()) await rmdir(path);
  // if the file name is not a directory, remove it
  else await unlink(path);
  // report that the file deletion was successful
  return {status: 204};
};

// === MAKE DIRECTORY (MKCOL) ===
// --- reference: https://www.geeksforgeeks.org/how-to-create-a-directory-using-node-js/ ---

// get access, remove, mkdir from fs
const {access, remove, mkdir,} = require("fs"); 

// make collection 
methods.MKCOL = async function(request) {
  // translate the urlinto a file name
  let path = urlPath(request.url);
  // access path to check if it exists
  access(path, (error) => { 
    // check if given directory already exists or not 
    if (error) { 
      // If current directory does not exist then create it 
      mkdir(path, { recursive: true }, (error) => {  if (error) {  console.log(error); } }); 
    } 
  }); 
  // report successful creation of directory
  return {status: 204};
};